﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class TabInfo
{
    public string playerName;
    //
    public string roleName;
    public string status;
}