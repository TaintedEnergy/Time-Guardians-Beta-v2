﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class InvSlotInfo
{
    public string itemName;

    public int clipAmmo;
    public int totalAmmo;
}