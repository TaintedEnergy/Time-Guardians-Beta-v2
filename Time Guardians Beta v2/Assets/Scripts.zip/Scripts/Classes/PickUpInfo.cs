﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class PickUpInfo
{
    public string itemName;
    public string itemSlotType;
    
    public GameObject obj;
}
