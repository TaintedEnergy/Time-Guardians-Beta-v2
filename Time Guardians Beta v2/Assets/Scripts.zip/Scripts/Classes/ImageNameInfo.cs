﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class ImageNameInfo
{
    public string imageName;
    public Sprite image;
}