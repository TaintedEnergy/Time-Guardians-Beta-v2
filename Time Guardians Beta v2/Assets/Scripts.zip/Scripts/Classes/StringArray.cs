﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class StringArray
{
    public string[] stringArray;
}
