﻿using UnityEngine;
using System.Collections;

[System.Serializable]
public class HurtInfo
{
    public string hurtName;
    public Color color;
    public int minDamage;
}
